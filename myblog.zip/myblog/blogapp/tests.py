from django.test import TestCase

# Create your tests here.
num = 1
gender = 'man' if num == 1 else 'women'
print(gender)